#include <math.h>
#include "enemy.h"
#include "render.h"
#include "player.h"

float enemy_x[64];
float enemy_y[64];
int enemy_count = 0;

void init_enemies()
{
    enemy_count = 0;

    for (int y=0; y<15; y++)
    for (int x=0; x<15; x++)
    {
        if (worldmap[y][x] == 9)
        {
            enemy_x[enemy_count] = x + 0.5f;
            enemy_y[enemy_count] = y + 0.5f;
            enemy_count++;
        }
    }
}

void update_enemies(float dt)
{
    float speed = 1.2f * dt;

    for (int i=0; i<enemy_count; i++)
    {
        float ex = enemy_x[i];
        float ey = enemy_y[i];

        float dx = px - ex;
        float dy = py - ey;
        float dist = sqrtf(dx*dx + dy*dy);

        if (dist < 0.001f) continue;

        dx /= dist;
        dy /= dist;

        float nx = ex + dx * speed;
        float ny = ey + dy * speed;

        int tx = (int)nx;
        int ty = (int)ny;

        if (worldmap[ty][tx] != 2 && worldmap[ty][tx] != 3)
        {
            enemy_x[i] = nx;
            enemy_y[i] = ny;
        }

        // damage if near
        if (dist < 0.35f)
        {
            hp -= 20 * dt;
            if (hp < 0) hp = 0;
        }
    }
}
