#include <SDL2/SDL.h>
#include <math.h>
#include "player.h"

float px = 3.0f;
float py = 3.0f;
float angle = 0.0f;

int gun_recoil_timer = 0;
int shot_fired = 0;



int hp = 100;
int ammo = 999;   // unlimited for now

float moveSpeed = 2.0f;    // movement per second
float rotSpeed  = 1.0f;    // rotation per second

void init_player()
{
    px = 3.0f;
    py = 3.0f;
    angle = 0.0f;
    hp = 100;
}

void update_player(float dt)
{
    const Uint8 *k = SDL_GetKeyboardState(NULL);

    // rotation
    if (k[SDL_SCANCODE_LEFT])  angle -= rotSpeed * dt;
    if (k[SDL_SCANCODE_RIGHT]) angle += rotSpeed * dt;

    float nx = px;
    float ny = py;

    // forward/back
    if (k[SDL_SCANCODE_W]) {
        nx += cosf(angle) * moveSpeed * dt;
        ny += sinf(angle) * moveSpeed * dt;
    }
    if (k[SDL_SCANCODE_S]) {
        nx -= cosf(angle) * moveSpeed * dt;
        ny -= sinf(angle) * moveSpeed * dt;
    }

    // strafe
    if (k[SDL_SCANCODE_A]) {
        nx += cosf(angle - M_PI/2) * moveSpeed * dt;
        ny += sinf(angle - M_PI/2) * moveSpeed * dt;
    }
    if (k[SDL_SCANCODE_D]) {
        nx += cosf(angle + M_PI/2) * moveSpeed * dt;
        ny += sinf(angle + M_PI/2) * moveSpeed * dt;
    }

    px = nx;
    py = ny;
}
