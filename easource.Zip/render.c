#include <SDL2/SDL.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "render.h"
#include "player.h"

#define W 800
#define H 600

// ======================================================
// TEXTURES
// ======================================================
SDL_Texture *texWall1 = NULL;
SDL_Texture *texWall2 = NULL;
SDL_Texture *texFloor = NULL;
SDL_Texture *texCeil  = NULL;
SDL_Texture *texKey   = NULL;
SDL_Texture *texEnemy = NULL;
SDL_Texture *texEnemyDie = NULL;
SDL_Texture *texGun   = NULL;
SDL_Texture *texGunRecoil = NULL;

int wall1W, wall1H;
int wall2W, wall2H;
int floorW, floorH;
int ceilW,  ceilH;
int keyW, keyH;
int enemyW, enemyH;
int gunW, gunH;
int gunR_W, gunR_H;

// ======================================================
// ASSET PATH SYSTEM
// ======================================================
char ASSET_PATH[512];

void init_asset_path()
{
    char *base = SDL_GetBasePath();
    if (!base)
    {
        strcpy(ASSET_PATH, "ASSETS/");
        return;
    }
    snprintf(ASSET_PATH, sizeof(ASSET_PATH), "%sASSETS/", base);
    SDL_free(base);
}

void build_path(char *out, const char *file)
{
    snprintf(out, 512, "%s%s", ASSET_PATH, file);
}

// ======================================================
// ENEMY DEATH TIMER
// ======================================================
int enemyDieTimer[15][15] = {0};

// ======================================================
// WORLD MAP
// ======================================================
int worldmap[15][15] =
{
    {2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
    {2,0,0,0,0,0,0,1,0,0,0,0,0,0,2},
    {2,0,0,2,2,0,0,0,0,2,2,0,0,0,2},
    {2,0,0,3,0,0,0,0,0,0,2,0,3,0,2},
    {2,0,0,2,0,9,3,0,0,0,2,0,2,0,2},
    {2,0,0,0,0,0,2,0,0,0,0,0,2,0,2},
    {2,0,2,2,2,0,3,0,0,2,2,0,2,0,2},
    {2,0,0,0,2,0,2,0,0,9,0,0,3,0,2},
    {2,0,0,0,2,0,2,0,2,2,2,0,2,0,2},
    {2,0,0,0,9,0,0,0,0,0,3,0,2,0,2},
    {2,0,3,2,2,2,2,2,2,0,2,0,3,0,2},
    {2,0,0,0,0,0,0,0,2,0,3,0,2,0,2},
    {2,0,2,2,2,2,3,0,2,0,2,0,3,0,2},
    {2,0,0,9,0,0,2,0,0,0,3,9,0,0,2},
    {2,2,2,2,2,2,2,2,2,2,2,2,2,2,2}
};

// ======================================================
// BMP Loader
// ======================================================
SDL_Texture* load_bmp_ck(SDL_Renderer *r, const char *file,
                         int *outW, int *outH, int transparent)
{
    char full[512];
    build_path(full, file);

    SDL_Surface *s = SDL_LoadBMP(full);
    if (!s)
    {
        SDL_Log("FAILED TO LOAD: %s", full);
        return NULL;
    }

    if (transparent)
        SDL_SetColorKey(s, 1, SDL_MapRGB(s->format, 0,0,0));

    if (outW) *outW = s->w;
    if (outH) *outH = s->h;

    SDL_Texture *t = SDL_CreateTextureFromSurface(r, s);
    SDL_FreeSurface(s);
    return t;
}

// ======================================================
// Load all textures
// ======================================================
void load_textures(SDL_Renderer *r)
{
    init_asset_path();

    texWall1 = load_bmp_ck(r,"wall1.bmp",&wall1W,&wall1H,0);
    texWall2 = load_bmp_ck(r,"wall2.bmp",&wall2W,&wall2H,0);
    texFloor = load_bmp_ck(r,"floor.bmp",&floorW,&floorH,0);
    texCeil  = load_bmp_ck(r,"ceiling.bmp",&ceilW,&ceilH,0);

    texKey   = load_bmp_ck(r,"key.bmp",&keyW,&keyH,1);

    texEnemy     = load_bmp_ck(r,"enemy.bmp",&enemyW,&enemyH,1);
    texEnemyDie  = load_bmp_ck(r,"enemy_die.bmp",&enemyW,&enemyH,1);

    texGun   = load_bmp_ck(r,"gun.bmp",&gunW,&gunH,1);
    texGunRecoil = load_bmp_ck(r,"gun_recoil.bmp",&gunR_W,&gunR_H,1);
}

// ======================================================
// Raycasting
// ======================================================
void draw_world(SDL_Renderer *r)
{
    for (int screenX = 0; screenX < W; screenX++)
    {
        float ray = (angle - 0.3f) + (screenX/(float)W)*0.6f;

        float dist = 0;
        int hit = 0;
        int tile = 0;
        float rx, ry;

        while (!hit && dist < 30.0f)
        {
            dist += 0.02f;
            rx = px + cosf(ray)*dist;
            ry = py + sinf(ray)*dist;

            int cell = worldmap[(int)ry][(int)rx];
            if (cell == 2 || cell == 3)
            {
                hit = 1;
                tile = cell;
            }
        }

        float lineH = 240.0f / dist;
        if (lineH > H) lineH = H;

        int ceilY  = H/2 - lineH/2;
        int floorY = H/2 + lineH/2;

        SDL_RenderCopy(r, texCeil, NULL, &(SDL_Rect){screenX,0,1,ceilY});
        SDL_RenderCopy(r, texFloor,NULL,&(SDL_Rect){screenX,floorY,1,H-floorY});

        SDL_Texture *T = (tile==2 ? texWall1 : texWall2);
        SDL_RenderCopy(r, T,NULL,&(SDL_Rect){screenX,ceilY,1,(int)lineH});
    }
}

// ======================================================
// Draw Keys
// ======================================================
void draw_keys(SDL_Renderer *r)
{
    for (int y=0; y<15; y++)
    for (int x=0; x<15; x++)
    {
        if (worldmap[y][x] != 1) continue;

        float dx = (x+0.5f) - px;
        float dy = (y+0.5f) - py;

        float dist = sqrtf(dx*dx + dy*dy);
        float dir  = atan2f(dy,dx) - angle;

        while(dir>3.14f)  dir-=6.28f;
        while(dir<-3.14f) dir+=6.28f;

        if (fabsf(dir) < 0.3f)
        {
            float sx = (dir+0.3f)/0.6f * W;
            float size = 80/dist;

            SDL_Rect d={(int)(sx-size/2),H/2-(int)size/2,(int)size,(int)size};
            SDL_RenderCopy(r, texKey,NULL,&d);
        }
    }
}

// ======================================================
// Draw enemies
// ======================================================
void draw_enemies(SDL_Renderer *r)
{
    const Uint8 *key = SDL_GetKeyboardState(NULL);
    int firing = key[SDL_SCANCODE_SPACE];

    for (int y=0; y<15; y++)
    for (int x=0; x<15; x++)
    {
        // death animation
        if (enemyDieTimer[y][x] > 0)
        {
            float ex = x+0.5f;
            float ey = y+0.5f;

            float dx = ex - px;
            float dy = ey - py;

            float dist = sqrtf(dx*dx + dy*dy);
            float dir  = atan2f(dy,dx) - angle;

            while(dir>3.14f)  dir-=6.28f;
            while(dir<-3.14f) dir+=6.28f;

            if (fabsf(dir) < 0.3f)
            {
                float sx = (dir+0.3f)/0.6f * W;
                float size = 170/dist;

                SDL_Rect d={(int)(sx-size/2),H/2-(int)size/2,(int)size,(int)size};
                SDL_RenderCopy(r, texEnemyDie,NULL,&d);
            }

            enemyDieTimer[y][x]--;
            if (enemyDieTimer[y][x] <= 0)
                worldmap[y][x] = 0;

            continue;
        }

        if (worldmap[y][x] != 9) continue;

        float ex = x+0.5f;
        float ey = y+0.5f;

        float dx = ex - px;
        float dy = ey - py;
        float dist = sqrtf(dx*dx + dy*dy);
        float dir  = atan2f(dy,dx) - angle;

        while(dir>3.14f)  dir-=6.28f;
        while(dir<-3.14f) dir+=6.28f;

        if (fabsf(dir) < 0.3f)
        {
            float sx = (dir+0.3f)/0.6f * W;
            float size = 170/dist;

            SDL_Rect d={(int)(sx-size/2),H/2-(int)size/2,(int)size,(int)size};
            SDL_RenderCopy(r, texEnemy,NULL,&d);

            // hit check
            if (firing && fabsf(dir)<0.05f && dist < 7.0f)
                enemyDieTimer[y][x] = 20;
        }
    }
}

// ======================================================
// HUD
// ======================================================
void draw_hud(SDL_Renderer *r)
{
    SDL_SetRenderDrawColor(r,20,20,20,255);
    SDL_Rect bg = {0, H-80, W, 80};
    SDL_RenderFillRect(r, &bg);

    SDL_SetRenderDrawColor(r,255,0,0,255);
    SDL_Rect hpbar = {20, H-65, (int)(hp*2), 20};
    SDL_RenderFillRect(r, &hpbar);
}

// ======================================================
// Gun
// ======================================================
void draw_gun(SDL_Renderer *r)
{
    int gw = 200;
    int gh = 150;

    SDL_Rect d = {W/2-gw/2, H-gh-10, gw, gh};

    if (gun_recoil_timer > 0 && texGunRecoil)
    {
        SDL_RenderCopy(r, texGunRecoil,NULL,&d);
        gun_recoil_timer--;
    }
    else
    {
        SDL_RenderCopy(r, texGun,NULL,&d);
    }
}

