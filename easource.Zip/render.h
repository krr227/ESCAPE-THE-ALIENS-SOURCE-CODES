#ifndef RENDER_H
#define RENDER_H

#include <SDL2/SDL.h>

extern int worldmap[15][15];
extern int enemyDieTimer[15][15];

// Textures loaded once
void load_textures(SDL_Renderer *r);

// Drawing
void draw_world(SDL_Renderer *r);
void draw_keys(SDL_Renderer *r);
void draw_enemies(SDL_Renderer *r);
void draw_hud(SDL_Renderer *r);
void draw_gun(SDL_Renderer *r);

// Asset system
void init_asset_path();

#endif
