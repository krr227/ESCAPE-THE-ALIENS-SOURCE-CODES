#ifndef PLAYER_H
#define PLAYER_H

extern float px, py;   // player position
extern float angle;    // looking direction
extern int hp;
extern int ammo;
extern int shot_fired;
extern int gun_recoil_timer;


void init_player();
void update_player(float dt);

#endif
