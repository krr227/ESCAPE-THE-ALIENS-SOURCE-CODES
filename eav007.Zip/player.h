#ifndef PLAYER_H
#define PLAYER_H

extern float px, py;
extern float angle;

extern int hp;
extern int ammo;

extern int gun_recoil_timer;
extern int shot_fired;

extern int hasKey;
extern int escaped;

void init_player();
void update_player(float dt);

#endif
