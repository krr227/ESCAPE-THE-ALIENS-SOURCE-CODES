#ifndef ENEMY_H
#define ENEMY_H

void init_enemies();
void update_enemies(float dt);

extern float enemy_x[64];
extern float enemy_y[64];
extern int enemy_count;

#endif
