#include <SDL2/SDL.h>
#include <math.h>
#include "player.h"
#include "render.h"

float px = 3.0f;
float py = 3.0f;
float angle = 0.0f;

int gun_recoil_timer = 0;
int shot_fired = 0;

int hasKey = 0;
int escaped = 0;

int hp = 100;
int ammo = 999;

float moveSpeed = 2.0f;
float rotSpeed  = 1.0f;

void init_player()
{
    px = 3.0f;
    py = 3.0f;
    angle = 0.0f;

    hp = 100;
    ammo = 999;

    hasKey = 0;
    escaped = 0;

    gun_recoil_timer = 0;
    shot_fired = 0;
}

void update_player(float dt)
{
    const Uint8 *k = SDL_GetKeyboardState(NULL);

    // rotation
    if (k[SDL_SCANCODE_LEFT])  angle -= rotSpeed * dt;
    if (k[SDL_SCANCODE_RIGHT]) angle += rotSpeed * dt;

    float nx = px;
    float ny = py;

    // movement
    if (k[SDL_SCANCODE_W]) { nx += cosf(angle)*moveSpeed*dt; ny += sinf(angle)*moveSpeed*dt; }
    if (k[SDL_SCANCODE_S]) { nx -= cosf(angle)*moveSpeed*dt; ny -= sinf(angle)*moveSpeed*dt; }
    if (k[SDL_SCANCODE_A]) { nx += cosf(angle - M_PI/2)*moveSpeed*dt; ny += sinf(angle - M_PI/2)*moveSpeed*dt; }
    if (k[SDL_SCANCODE_D]) { nx += cosf(angle + M_PI/2)*moveSpeed*dt; ny += sinf(angle + M_PI/2)*moveSpeed*dt; }

    int tx = (int)nx;
    int ty = (int)ny;

    // walls block movement (2 = wall)
    if (worldmap[ty][tx] != 2)
    {
        px = nx;
        py = ny;
    }

    // SHOOT (SPACE)
    if (k[SDL_SCANCODE_SPACE])
    {
        if (gun_recoil_timer == 0)
        {
            gun_recoil_timer = 6;
            shot_fired = 1;
        }
    }
    else
    {
        shot_fired = 0;
    }

    // INTERACTION (E)
    static int lastE = 0;
    int currE = k[SDL_SCANCODE_E];

    if (currE && !lastE)
    {
        for (int y=0; y<15; y++)
        for (int x=0; x<15; x++)
        {
            float cx = x+0.5f;
            float cy = y+0.5f;

            float dx = cx - px;
            float dy = cy - py;

            float dist = sqrtf(dx*dx + dy*dy);
            int tile = worldmap[y][x];

            // pick up key
            if (tile == 1 && dist < 0.7f)
            {
                worldmap[y][x] = 0;
                hasKey = 1;
            }
            // open door (3)
            else if (tile == 3 && dist < 1.0f && hasKey)
            {
                worldmap[y][x] = 0;
                escaped = 1;
            }
        }
    }

    lastE = currE;
}
