#include <SDL2/SDL.h>
#include <math.h>
#include <stdio.h>
#include "render.h"
#include "player.h"
#include "enemy.h"

#define W 800
#define H 600

// ------------------------------------------------------------
// WORLD MAP
// 2 = wall
// 3 = door (can be opened with E if key is held)
// 1 = key
// 0 = empty
// 9 = enemy spawn point
// ------------------------------------------------------------
int worldmap[15][15] =
{
    {2,2,2,2,2,2,4,4,4,4,2,2,2,2,2},
    {2,0,0,0,0,0,0,1,0,0,0,0,0,0,2},
    {2,0,0,2,2,0,0,0,0,2,2,0,0,0,2},
    {2,0,0,2,0,0,0,0,0,0,4,0,2,0,4},
    {2,0,0,2,0,9,0,0,0,0,2,0,2,0,4},
    {2,0,0,0,0,0,2,0,0,0,0,0,2,0,2},
    {2,0,2,2,2,0,2,0,0,2,2,0,2,0,2},
    {2,0,0,0,2,0,2,0,0,9,0,0,2,0,3},
    {2,0,0,0,2,0,2,0,2,2,2,0,2,0,2},
    {2,0,0,0,9,0,0,0,0,0,0,0,2,0,2},
    {2,0,2,2,4,4,4,2,2,0,2,0,3,0,2},
    {2,0,0,0,0,0,0,0,2,0,0,0,2,0,2},
    {2,0,2,2,2,2,2,0,2,0,2,0,0,0,2},
    {2,0,0,9,0,0,2,0,0,0,2,9,0,0,2},
    {2,2,2,2,2,2,2,2,2,2,2,2,2,2,2}
};

// enemy death timers
int enemyDieTimer[15][15] = {0};

// ------------------------------------------------------------
// TEXTURES
// ------------------------------------------------------------
SDL_Texture *texWall1, *texWall2, *texDoor;
SDL_Texture *texFloor, *texCeil;
SDL_Texture *texKey;
SDL_Texture *texEnemy, *texEnemyDie;
SDL_Texture *texGun, *texGunRecoil;
SDL_Texture *texEscape;

int wallW, wallH;
int floorW, floorH;
int ceilW, ceilH;
int keyW, keyH;
int enemyW, enemyH;
int gunW, gunH;
int gunR_W, gunR_H;
int doorW, doorH;
int escapeW, escapeH;

// ------------------------------------------------------------
// ASSET PATH
// ------------------------------------------------------------
char ASSET_PATH[512];

void init_asset_path()
{
    char *base = SDL_GetBasePath();
    if (!base)
    {
        strcpy(ASSET_PATH, "ASSETS/");
        return;
    }
    snprintf(ASSET_PATH, sizeof(ASSET_PATH), "%sASSETS/", base);
    SDL_free(base);
}

void build_path(char *dst, const char *file)
{
    snprintf(dst, 512, "%s%s", ASSET_PATH, file);
}

// BMP loader with optional colorkey
SDL_Texture* load_tex(SDL_Renderer *r,const char *file,int *w,int *h,int ck)
{
    char full[512]; 
    build_path(full,file);

    SDL_Surface *s = SDL_LoadBMP(full);
    if(!s)
    {
        printf("FAILED TO LOAD: %s\n", full);
        return NULL;
    }

    if(ck) SDL_SetColorKey(s, 1, SDL_MapRGB(s->format, 0,0,0));

    if(w) *w = s->w;
    if(h) *h = s->h;

    SDL_Texture *t = SDL_CreateTextureFromSurface(r,s);
    SDL_FreeSurface(s);
    return t;
}

// ------------------------------------------------------------
// LOAD ALL TEXTURES
// ------------------------------------------------------------
void load_textures(SDL_Renderer *r)
{
    init_asset_path();

    texWall1 = load_tex(r,"wall1.bmp",&wallW,&wallH,0);
    texWall2 = load_tex(r,"wall2.bmp",&wallW,&wallH,0);
    texDoor  = load_tex(r,"door.bmp",&doorW,&doorH,1);

    texFloor = load_tex(r,"floor.bmp",&floorW,&floorH,0);
    texCeil  = load_tex(r,"ceiling.bmp",&ceilW,&ceilH,0);

    texKey = load_tex(r,"key.bmp",&keyW,&keyH,1);

    texEnemy = load_tex(r,"enemy.bmp",&enemyW,&enemyH,1);
    texEnemyDie = load_tex(r,"enemy_die.bmp",&enemyW,&enemyH,1);

    texGun = load_tex(r,"gun.bmp",&gunW,&gunH,1);
    texGunRecoil = load_tex(r,"gun_recoil.bmp",&gunR_W,&gunR_H,1);

    texEscape = load_tex(r,"escape.bmp",&escapeW,&escapeH,0);
}

// ------------------------------------------------------------
// WALL TEXTURE SELECTOR
// ------------------------------------------------------------
SDL_Texture* getWallTex(int tile)
{
    if (tile == 2) return texWall1;
    if (tile == 3) return texDoor;      // door texture
    if (tile == 4) return texWall2;     // optional extra wall
    return texWall1;
}

// ------------------------------------------------------------
// RAYCAST WALL RENDERING (with texture striping)
// ------------------------------------------------------------
void draw_world(SDL_Renderer *r)
{
    for(int sx=0; sx<W; sx++)
    {
        float ray = (angle - 0.3f) + (sx/(float)W)*0.6f;

        float dist = 0;
        int hit = 0;
        int tile = 0;
        float rx, ry;

        // Ray marching
        while(!hit && dist < 30.0f)
        {
            dist += 0.01f;
            rx = px + cosf(ray)*dist;
            ry = py + sinf(ray)*dist;

            int cx = (int)rx;
            int cy = (int)ry;

            int cell = worldmap[cy][cx];
            if (cell >= 2)
            {
                tile = cell;
                hit = 1;
            }
        }

        float lineH = 240.0f / dist;
        if(lineH > H) lineH = H;

        int ceilY = H/2 - lineH/2;
        int floorY = H/2 + lineH/2;

        // draw ceiling and floor as vertical strips
        SDL_RenderCopy(r, texCeil, NULL, &(SDL_Rect){sx,0,1,ceilY});
        SDL_RenderCopy(r, texFloor,NULL,&(SDL_Rect){sx,floorY,1,H-floorY});

        SDL_Texture *T = getWallTex(tile);
        if(!T) continue;

        // calculate which part of the texture to sample
        float hitX = rx - floorf(rx);
        float hitY = ry - floorf(ry);
        float texCoord = (fabs(hitX) > fabs(hitY)) ? hitX : hitY;
        if(texCoord < 0) texCoord = -texCoord;

        int tw, th;
        SDL_QueryTexture(T,NULL,NULL,&tw,&th);

        int srcX = (int)(texCoord * tw);

        SDL_Rect src = { srcX, 0, 1, th };
        SDL_Rect dst = { sx, ceilY, 1, (int)lineH };

        SDL_RenderCopy(r, T, &src, &dst);
    }
}

// ------------------------------------------------------------
// KEY RENDERING
// ------------------------------------------------------------
void draw_keys(SDL_Renderer *r)
{
    for(int y=0;y<15;y++)
    for(int x=0;x<15;x++)
    {
        if(worldmap[y][x] != 1) continue;

        float dx = (x+0.5f) - px;
        float dy = (y+0.5f) - py;

        float dist = sqrtf(dx*dx + dy*dy);
        float dir = atan2f(dy,dx) - angle;

        while(dir >  M_PI) dir -= 2*M_PI;
        while(dir < -M_PI) dir += 2*M_PI;

        if(fabs(dir) < 0.3f)
        {
            float sx = (dir+0.3f)/0.6f * W;
            float size = 80/dist;

            SDL_Rect d = { (int)(sx-size/2), H/2-(int)size/2, (int)size, (int)size };
            SDL_RenderCopy(r, texKey, NULL, &d);
        }
    }
}

// ------------------------------------------------------------
// ENEMY RENDERING
// ------------------------------------------------------------
void draw_enemies(SDL_Renderer *r)
{
    for(int i=0; i<enemy_count; i++)
    {
        float ex = enemy_x[i];
        float ey = enemy_y[i];

        float dx = ex - px;
        float dy = ey - py;

        float dist = sqrtf(dx*dx + dy*dy);
        float dir  = atan2f(dy,dx) - angle;

        while(dir >  M_PI) dir -= 2*M_PI;
        while(dir < -M_PI) dir += 2*M_PI;

        if(fabs(dir) < 0.3f)
        {
            float sx = (dir+0.3f)/0.6f * W;
            float size = 170/dist;

            SDL_Rect d = { (int)(sx-size/2), H/2-(int)size/2, (int)size, (int)size };
            SDL_RenderCopy(r, texEnemy, NULL, &d);
        }
    }
}

// ------------------------------------------------------------
// HUD
// ------------------------------------------------------------
void draw_hud(SDL_Renderer *r)
{
    SDL_SetRenderDrawColor(r,20,20,20,255);
    SDL_Rect bg = {0,H-80,W,80};
    SDL_RenderFillRect(r,&bg);

    SDL_SetRenderDrawColor(r,255,0,0,255);
    SDL_Rect hpbar = {20,H-65,(int)(hp*2),20};
    SDL_RenderFillRect(r,&hpbar);
}

// ------------------------------------------------------------
// GUN + RECOIL
// ------------------------------------------------------------
void draw_gun(SDL_Renderer *r)
{
    int gw=200, gh=150;
    SDL_Rect d = {W/2-gw/2, H-gh-10, gw, gh};

    if(gun_recoil_timer > 0)
    {
        SDL_RenderCopy(r, texGunRecoil, NULL, &d);
        gun_recoil_timer--;
    }
    else
    {
        SDL_RenderCopy(r, texGun, NULL, &d);
    }
}

// ------------------------------------------------------------
// ESCAPE SCREEN
// ------------------------------------------------------------
void draw_escape(SDL_Renderer *r)
{
    SDL_Rect d = {0,0,W,H};
    SDL_RenderCopy(r, texEscape, NULL, &d);
}
