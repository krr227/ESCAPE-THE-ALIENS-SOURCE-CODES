#include <SDL2/SDL.h>
#include <stdio.h>
#include "game.h"
#include "render.h"
#include "player.h"
#include "enemy.h"

// ======================================================
// GLOBAL AUDIO STATE
// ======================================================
static SDL_AudioDeviceID audioDev = 0;
static Uint8 *audioBuf = NULL;
static Uint32 audioLen = 0;

// WAV 길이가 43초라고 했으므로
static const float MUSIC_LENGTH_SEC = 43.0f;

static float musicTimer = 0.0f;


// ======================================================
// Play once
// ======================================================
void play_bgm()
{
    if (!audioDev || !audioBuf || audioLen == 0)
        return;

    SDL_ClearQueuedAudio(audioDev);              // 큐 비우기
    SDL_QueueAudio(audioDev, audioBuf, audioLen); // 다시 재생
    SDL_PauseAudioDevice(audioDev, 0);           // 재생 시작
}


// ======================================================
// Load WAV + prepare looping
// ======================================================
void init_bgm()
{
    SDL_AudioSpec wavSpec;

    char path[256];
    snprintf(path, sizeof(path), "ASSETS/bgm.wav");

    if (SDL_LoadWAV(path, &wavSpec, &audioBuf, &audioLen) == NULL)
    {
        printf("[ERROR] WAV load failed: %s\n", SDL_GetError());
        return;
    }

    audioDev = SDL_OpenAudioDevice(NULL, 0, &wavSpec, NULL, 0);
    if (audioDev == 0)
    {
        printf("[ERROR] Audio device failed: %s\n", SDL_GetError());
        SDL_FreeWAV(audioBuf);
        audioBuf = NULL;
        return;
    }

    printf("[OK] Loaded BGM (%u bytes), starting playback\n", audioLen);

    // 첫 재생
    play_bgm();
    musicTimer = 0.0f;
}


// ======================================================
// MAIN GAME LOOP
// ======================================================
void game_loop(SDL_Window *win, SDL_Renderer *renderer)
{
    SDL_Event e;
    int running = 1;

    Uint32 lastTick = SDL_GetTicks();

    init_player();
    init_enemies();
    load_textures(renderer);
    init_bgm();   // ★ BGM 초기화

    while (running)
    {
        Uint32 now = SDL_GetTicks();
        float dt = (now - lastTick) / 1000.0f;
        lastTick = now;

        // ---- EVENT ----
        while (SDL_PollEvent(&e))
        {
            if (e.type == SDL_QUIT)
                running = 0;

            if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_ESCAPE)
                running = 0;
        }

        // ---- UPDATE ----
        // Only update game logic if the player has not yet escaped
        if (!escaped)
        {
            update_player(dt);
            update_enemies(dt);
        }

        // ---- AUDIO LOOP TIMER ----
        musicTimer += dt;
        if (musicTimer >= MUSIC_LENGTH_SEC)
        {
            // 43초가 지나면 곡 다시 재생
            play_bgm();
            musicTimer = 0.0f;
        }

        // ---- RENDER ----
        SDL_SetRenderDrawColor(renderer,0,0,0,255);
        SDL_RenderClear(renderer);

        if (escaped)
        {
            // when escaped, only show escape screen
            draw_escape(renderer);
        }
        else
        {
            draw_world(renderer);
            draw_keys(renderer);
            draw_enemies(renderer);
            draw_hud(renderer);
            draw_gun(renderer);
        }

        SDL_RenderPresent(renderer);

        SDL_Delay(1);
    }

    // Clean audio
    if (audioDev)
        SDL_CloseAudioDevice(audioDev);
    if (audioBuf)
        SDL_FreeWAV(audioBuf);

    SDL_Quit();
}
